﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FrbaOfertas
{
    public partial class MenuPrincipal : Form
    {
        public MenuPrincipal()
        {
            InitializeComponent();
        }

        private void btnAbmRoles_Click(object sender, EventArgs e)
        {

        }

        private void btnPagarReserva_Click(object sender, EventArgs e)
        {

        }

        private void btnReservarViaje_Click(object sender, EventArgs e)
        {

        }

        private void btnComprarViaje_Click(object sender, EventArgs e)
        {

        }

        private void btnGenerarViaje_Click(object sender, EventArgs e)
        {

        }

        private void btnListadoEstadistico_Click(object sender, EventArgs e)
        {

        }

        private void btnAbmPuertos_Click(object sender, EventArgs e)
        {

        }

        private void btnAbmRecorrido_Click(object sender, EventArgs e)
        {

        }

        private void btnAbmCruceros_Click(object sender, EventArgs e)
        {

        }

        private void btnVolver_Click(object sender, EventArgs e)
        {

        }

        private void labelMenuPrincipal_Click(object sender, EventArgs e)
        {

        }
    }
}
